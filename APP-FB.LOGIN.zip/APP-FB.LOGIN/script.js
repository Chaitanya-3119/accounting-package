document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault();
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    if (email && password) {
        alert('Logging in...');
        // Simulate a back-end login logic here
        // You can add an AJAX request or fetch here for backend authentication
    } else {
        alert('Please enter your email and password');
    }
});
